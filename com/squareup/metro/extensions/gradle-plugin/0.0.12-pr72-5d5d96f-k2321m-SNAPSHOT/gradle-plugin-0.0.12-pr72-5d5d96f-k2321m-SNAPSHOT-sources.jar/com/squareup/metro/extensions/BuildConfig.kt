package com.squareup.metro.extensions

import kotlin.String

internal const val VERSION: String = "0.0.12-pr72-5d5d96f-k2321m-SNAPSHOT"

internal const val GROUP: String = "com.squareup.metro.extensions"
