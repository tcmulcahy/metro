package com.squareup.metro.extensions

import org.jetbrains.kotlin.name.ClassId
import org.jetbrains.kotlin.name.FqName
import org.jetbrains.kotlin.name.Name

internal object ClassIds {
  val SCOPED = ClassId(FqName("mortar"), Name.identifier("Scoped"))

  val CONTRIBUTES_TO = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("ContributesTo"))

  val CONTRIBUTES_BINDING =
    ClassId(FqName("dev.zacsweers.metro"), Name.identifier("ContributesBinding"))

  val CONTRIBUTES_INTO_SET =
    ClassId(FqName("dev.zacsweers.metro"), Name.identifier("ContributesIntoSet"))

  val CONTRIBUTES_INTO_MAP =
    ClassId(FqName("dev.zacsweers.metro"), Name.identifier("ContributesIntoMap"))

  val DEPENDENCY_GRAPH = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("DependencyGraph"))

  val BINDS = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Binds"))

  val BINDING_CONTAINER =
    ClassId(FqName("dev.zacsweers.metro"), Name.identifier("BindingContainer"))

  val INTO_SET = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("IntoSet"))

  val FOR_SCOPE = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("ForScope"))

  val SCREEN_ROBOT =
    ClassId(FqName("com.squareup.instrumentation.robots"), Name.identifier("ScreenRobot"))

  val COMPOSE_SCREEN_ROBOT =
    ClassId(
      FqName("com.squareup.instrumentation.robots.compose"),
      Name.identifier("ComposeScreenRobot"),
    )

  val ROBOT_FQ_NAMES = listOf(SCREEN_ROBOT, COMPOSE_SCREEN_ROBOT)

  val PROVIDES = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Provides"))

  val INJECT = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Inject"))

  val SINGLE_IN = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("SingleIn"))

  val METRO_SCOPE = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Scope"))

  val JAVAX_SCOPE = ClassId(FqName("javax.inject"), Name.identifier("Scope"))

  val SCOPE_CLASS_IDS = setOf(METRO_SCOPE, JAVAX_SCOPE)

  val PROVIDER = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Provider"))

  val SERVICE_CREATOR = ClassId(FqName("com.squareup.api"), Name.identifier("ServiceCreator"))

  val REAL_SERVICE = ClassId(FqName("com.squareup.api"), Name.identifier("RealService"))

  val FAKE_MODE = ClassId(FqName("com.squareup.development"), Name.identifier("FakeMode"))

  val FEATURE_FLAG = ClassId(FqName("com.squareup.featureflags"), Name.identifier("FeatureFlag"))

  val APP_SCOPE = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("AppScope"))

  val DEVELOPMENT_APP_COMPONENT =
    ClassId(FqName("com.squareup.development.shell"), Name.identifier("DevelopmentAppComponent"))

  val DEVELOPMENT_APPLICATION =
    ClassId(FqName("com.squareup.development.shell"), Name.identifier("DevelopmentApplication"))

  val DEPENDENCY_GRAPH_FACTORY = DEPENDENCY_GRAPH.createNestedClassId(Name.identifier("Factory"))

  val DEVELOPMENT_APP_COMPONENT_FACTORY =
    DEVELOPMENT_APP_COMPONENT.createNestedClassId(Name.identifier("Factory"))

  val APPLICATION = ClassId(FqName("android.app"), Name.identifier("Application"))

  val ACTIVITY_SCOPE = ClassId(FqName("com.squareup.dagger"), Name.identifier("ActivityScope"))

  val LOGIN_SCREEN_MODULE =
    ClassId(
      FqName("com.squareup.development.shell.login.screen"),
      Name.identifier("LoginScreenModule"),
    )

  val DEVELOPMENT_LOGGED_IN_COMPONENT =
    ClassId(
      FqName("com.squareup.development.shell.component"),
      Name.identifier("DevelopmentLoggedInComponent"),
    )

  val DEVELOPMENT_LOGIN_SCREEN_COMPONENT =
    ClassId(
      FqName("com.squareup.development.shell.login.screen"),
      Name.identifier("DevelopmentLoginScreenComponent"),
    )

  val CONTRIBUTED_DEVELOPMENT_LOGIN_SCREEN_COMPONENT =
    ClassId(
      FqName("com.squareup.development.shell.login.screen"),
      Name.identifier("ContributedDevelopmentLoginScreenComponent"),
    )

  val DEFAULT_FEATURE_MODULE =
    ClassId(FqName("com.squareup.development.shell"), Name.identifier("DefaultFeatureModule"))

  val DEVELOPMENT_FEATURE_SCOPE_COMPONENT =
    ClassId(
      FqName("com.squareup.development.shell"),
      Name.identifier("DevelopmentFeatureScopeComponent"),
    )

  val BINDS_INSTANCE = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Provides"))

  val JAVAX_QUALIFIER = ClassId(FqName("javax.inject"), Name.identifier("Qualifier"))

  val ORIGIN = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Origin"))

  val METRO_QUALIFIER = ClassId(FqName("dev.zacsweers.metro"), Name.identifier("Qualifier"))

  val QUALIFIER_CLASS_IDS = setOf(JAVAX_QUALIFIER, METRO_QUALIFIER)

  /** Annotations that have a `replaces` parameter (index 2, except @ContributesTo at index 1). */
  val ANNOTATIONS_WITH_REPLACES =
    setOf(CONTRIBUTES_TO, CONTRIBUTES_BINDING, CONTRIBUTES_INTO_SET, CONTRIBUTES_INTO_MAP)
}
