/*
 * Copyright (C) 2014 The Dagger Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.zacsweers.metro.internal

import dev.zacsweers.metro.Provider
import kotlin.js.JsStatic
import kotlin.jvm.JvmStatic

/**
 * A [Factory] implementation used to implement [Map] bindings. This factory returns a `Map<K, V>`
 * when calling [invoke] (as specified by [Factory]).
 */
public class MapFactory<K : Any, V> private constructor(map: Map<K, Provider<V>>) :
  AbstractMapFactory<K, V, V>(map) {

  /**
   * Returns a `Map<K, V>` whose iteration order is that of the elements given by each of the
   * providers, which are invoked in the order given at creation.
   */
  override fun invoke(): Map<K, V> {
    val result = newLinkedHashMapWithExpectedSize<K, V>(contributingMap().size)
    for (entry in contributingMap().entries) {
      result[entry.key] = entry.value()
    }
    return result.toUnmodifiableMap()
  }

  /** A builder for [MapFactory]. */
  public class Builder<K : Any, V : Any> internal constructor(size: Int) :
    AbstractMapFactory.Builder<K, V, V>(size) {

    public override fun put(key: K, providerOfValue: Provider<V>): Builder<K, V> = apply {
      super.put(key, providerOfValue)
    }

    override fun putAll(mapOfProviders: Provider<Map<K, V>>): Builder<K, V> = apply {
      super.putAll(mapOfProviders)
    }

    /** Returns a new [MapFactory]. */
    public fun build(): MapFactory<K, V> {
      return MapFactory(map)
    }
  }

  public companion object {
    /** Returns a new [Builder] */
    @JvmStatic
    @JsStatic
    public fun <K : Any, V : Any> builder(size: Int): Builder<K, V> {
      return Builder(size)
    }

    /** Returns a provider of an empty map. */
    @JvmStatic
    @JsStatic
    public fun <K, V> empty(): Provider<Map<K, V>> {
      @Suppress("UNCHECKED_CAST") // safe contravariant cast
      return EMPTY as Provider<Map<K, V>>
    }

    /**
     * Returns a [Factory] for a single-entry `Map<K, V>` whose value is sourced from [provider].
     * Skips the [Builder] allocation for the size-1 case.
     */
    @JvmStatic
    @JsStatic
    public fun <K : Any, V : Any> singleton(key: K, provider: Provider<V>): Factory<Map<K, V>> =
      SingletonMapFactory(key, provider)
  }
}

private class SingletonMapFactory<K : Any, V : Any>(
  private val key: K,
  private val provider: Provider<V>,
) : Factory<Map<K, V>> {
  override fun invoke(): Map<K, V> = SingletonMap(key, provider())
}
