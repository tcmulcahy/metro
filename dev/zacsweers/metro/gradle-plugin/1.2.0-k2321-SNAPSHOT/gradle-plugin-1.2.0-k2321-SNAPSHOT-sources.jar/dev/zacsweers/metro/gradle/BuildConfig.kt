package dev.zacsweers.metro.gradle

import kotlin.String
import kotlin.collections.List

internal const val VERSION: String = "1.2.0-k2321-SNAPSHOT"

internal const val PLUGIN_ID: String = "dev.zacsweers.metro.compiler"

internal val SUPPORTED_KOTLIN_VERSIONS: List<String> =
    listOf("2.3.0", "2.3.10", "2.3.20", "2.3.21", "2.4.0-dev-2124", "2.4.0", "2.4.20-dev-835")
