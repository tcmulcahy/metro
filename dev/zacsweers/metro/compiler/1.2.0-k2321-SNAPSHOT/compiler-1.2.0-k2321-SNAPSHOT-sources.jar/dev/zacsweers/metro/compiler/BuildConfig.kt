package dev.zacsweers.metro.compiler

import kotlin.Int
import kotlin.String

internal const val METRO_VERSION: String = "1.2.0-k2321-SNAPSHOT"

internal const val PLUGIN_ID: String = "dev.zacsweers.metro.compiler"

internal const val METADATA_VERSION: Int = 1
