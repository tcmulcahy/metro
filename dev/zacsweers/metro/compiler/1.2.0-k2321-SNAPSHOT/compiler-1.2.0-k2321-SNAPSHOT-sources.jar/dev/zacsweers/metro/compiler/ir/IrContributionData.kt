// Copyright (C) 2025 Zac Sweers
// SPDX-License-Identifier: Apache-2.0
package dev.zacsweers.metro.compiler.ir

import androidx.collection.MutableScatterMap
import androidx.collection.MutableScatterSet
import androidx.collection.ScatterSet
import androidx.collection.mutableScatterSetOf
import dev.zacsweers.metro.ContributesBinding
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.SingleIn
import dev.zacsweers.metro.compiler.api.ir.MetroIrContributionExtension
import dev.zacsweers.metro.compiler.expectAsOrNull
import dev.zacsweers.metro.compiler.flatMapToSet
import dev.zacsweers.metro.compiler.getAndAdd
import dev.zacsweers.metro.compiler.ir.transformers.Lockable
import dev.zacsweers.metro.compiler.mapNotNullToSet
import dev.zacsweers.metro.compiler.mapToSet
import dev.zacsweers.metro.compiler.reportCompilerBug
import dev.zacsweers.metro.compiler.symbols.Symbols
import dev.zacsweers.metro.compiler.tracing.TraceScope
import dev.zacsweers.metro.compiler.tracing.trace
import java.util.concurrent.ConcurrentHashMap
import org.jetbrains.kotlin.descriptors.DescriptorVisibilities
import org.jetbrains.kotlin.ir.declarations.IrClass
import org.jetbrains.kotlin.ir.declarations.IrDeclaration
import org.jetbrains.kotlin.ir.declarations.IrDeclarationWithName
import org.jetbrains.kotlin.ir.types.IrType
import org.jetbrains.kotlin.ir.types.classOrFail
import org.jetbrains.kotlin.ir.types.classOrNull
import org.jetbrains.kotlin.ir.util.defaultType
import org.jetbrains.kotlin.ir.util.dumpKotlinLike
import org.jetbrains.kotlin.ir.util.fileOrNull
import org.jetbrains.kotlin.ir.util.nestedClasses
import org.jetbrains.kotlin.name.CallableId
import org.jetbrains.kotlin.name.ClassId

private typealias Scope = ClassId

@Inject
@SingleIn(IrScope::class)
@ContributesBinding(IrScope::class)
internal class IrContributionData(
  private val metroContext: IrMetroContext,
  private val irContributionExtensions: List<MetroIrContributionExtension>,
) : Lockable by Lockable() {

  private val contributions = MutableScatterMap<Scope, MutableScatterSet<IrType>>()
  // Lazily populated caches use ConcurrentHashMap for thread-safe access during parallel
  // graph extension validation. These are not structural mutations (just caching lookups),
  // so they remain writable after lock().
  private val externalContributions = ConcurrentHashMap<Scope, Set<IrType>>()
  private val scopeHintCache = ConcurrentHashMap<Scope, CallableId>()

  private fun scopeHintFor(scope: Scope): CallableId =
    scopeHintCache.getOrPut(scope) { Symbols.CallableIds.scopeHint(scope) }

  private val bindingContainerContributions = MutableScatterMap<Scope, MutableScatterSet<IrClass>>()
  private val externalBindingContainerContributions =
    MutableScatterMap<Scope, ScatterSet<IrClass>>()

  // External "raw" supertype contributions from IR extensions. Kept separate from `contributions`
  // because the latter holds nested `MetroContribution` markers, while these are top-level
  // interfaces (e.g., Hilt entry points) that don't have a contributing-class parent.
  private val extensionSupertypes = MutableScatterMap<Scope, Set<IrClass>>()

  // Cache for findVisibleContributionClassesForScopeInHints results.
  // This avoids redundant lookups when both findExternalContributions and
  // findExternalBindingContainerContributions are called for the same scope.
  private val visibleContributionClassesCache = MutableScatterMap<Scope, Set<IrClass>>()

  fun addContribution(scope: Scope, contribution: IrType) {
    checkNotLocked()
    contributions.getAndAdd(scope, contribution)
  }

  context(traceScope: TraceScope)
  fun getContributions(scope: Scope, callingDeclaration: IrDeclaration): Set<IrType> = buildSet {
    contributions[scope]?.forEach(::add)
    addAll(findExternalContributions(scope, callingDeclaration))
  }

  fun addBindingContainerContribution(scope: Scope, contribution: IrClass) {
    checkNotLocked()
    bindingContainerContributions.getAndAdd(scope, contribution)
  }

  context(traceScope: TraceScope)
  fun getBindingContainerContributions(
    scope: Scope,
    callingDeclaration: IrDeclaration,
  ): Set<IrClass> = buildSet {
    bindingContainerContributions[scope]?.forEach(::add)
    findExternalBindingContainerContributions(scope, callingDeclaration).forEach(::add)
  }

  /**
   * Returns "raw" supertype contributions from registered [MetroIrContributionExtension]s. These
   * are top-level types (e.g., Hilt entry-point interfaces) that should be added directly as graph
   * supertypes without parent promotion.
   */
  context(traceScope: TraceScope)
  fun getExtensionSupertypes(scope: Scope, callingDeclaration: IrDeclaration): Set<IrClass> {
    trackScopeHintLookup(scope, callingDeclaration)
    return extensionSupertypes.getOrPut(scope) {
      trace("Look up extension supertypes for $scope") {
        irContributionExtensions.flatMapToSet { extension ->
          extension.contributeSupertypes(scope, callingDeclaration).mapNotNullToSet { type ->
            type.classOrNull?.owner?.also { irClass ->
              with(metroContext) { trackClassLookup(callingDeclaration, irClass) }
            }
          }
        }
      }
    }
  }

  /**
   * Tracks a lookup on scope hint functions for incremental compilation. This should be called
   * before checking any caches to ensure all callers register their dependency on scope hint
   * changes.
   */
  fun trackScopeHintLookup(scope: Scope, callingDeclaration: IrDeclaration?) {
    callingDeclaration?.let { caller ->
      with(metroContext) {
        val scopeHintName = scopeHintFor(scope)
        trackClassLookup(
          callingDeclaration = caller,
          container = scopeHintName.packageName,
          declarationName = scopeHintName.callableName.asString(),
        )
      }
    }
  }

  fun findVisibleContributionClassesForScopeInHints(
    scope: Scope,
    callingDeclaration: IrDeclaration,
    includeNonFriendInternals: Boolean = false,
  ): Set<IrClass> {
    // Always track the lookup for incremental compilation
    trackScopeHintLookup(scope, callingDeclaration)

    // Check cache first (unless includeNonFriendInternals which changes the result)
    if (!includeNonFriendInternals) {
      visibleContributionClassesCache[scope]?.let { cached ->
        // Still need to track class lookups for IC even on cache hit
        for (irClass in cached) {
          context(metroContext) { trackClassLookup(callingDeclaration, irClass) }
        }
        return cached
      }
    }

    val functionsInPackage =
      context(metroContext) { callingDeclaration.lookupFunctions(scopeHintFor(scope)) }

    context(metroContext) {
      writeDiagnostic("discovered-hints-ir", "${scope.asFqNameString()}.txt") {
        functionsInPackage.map { it.owner.dumpKotlinLike() }.sorted().joinToString("\n") +
          "\n----\nCalled by:\n${callingDeclaration.expectAsOrNull<IrDeclarationWithName>()?.name}"
      }
    }

    val contributingClasses =
      functionsInPackage
        .filter { hintFunctionSymbol ->
          val hintFunction = hintFunctionSymbol.owner
          if (hintFunction.visibility == DescriptorVisibilities.INTERNAL) {
            includeNonFriendInternals ||
              callingDeclaration.fileOrNull?.let { file -> hintFunction.isVisibleAsInternal(file) }
                ?: false
          } else {
            true
          }
        }
        .mapToSet { contribution ->
          // This is the single value param
          contribution.owner.regularParameters.single().type.classOrFail.owner.also {
            // Ensure we also track the contributing class, not just the hint
            context(metroContext) { trackClassLookup(callingDeclaration, it) }
          }
        }

    // Cache the result (only for the default case without includeNonFriendInternals)
    if (!includeNonFriendInternals) {
      visibleContributionClassesCache[scope] = contributingClasses
    }

    return contributingClasses
  }

  // Note: Origin classes may be looked up multiple times if they contribute to multiple scopes.
  // findVisibleContributionClassesForScopeInHints is cached per scope, so redundant lookups
  // within the same scope are avoided.
  context(traceScope: TraceScope)
  private fun findExternalContributions(
    scope: Scope,
    callingDeclaration: IrDeclaration,
  ): Set<IrType> {
    // Track the lookup before checking the cache so all callers register their dependency
    trackScopeHintLookup(scope, callingDeclaration)
    return externalContributions.getOrPut(scope) {
      trace("Look up external contributions for $scope") {
        val contributingClasses =
          findVisibleContributionClassesForScopeInHints(
            scope,
            callingDeclaration = callingDeclaration,
          )
        getScopedContributions(contributingClasses, scope, bindingContainersOnly = false)
      }
    }
  }

  // Note: Origin classes may be looked up multiple times if they contribute to multiple scopes.
  // findVisibleContributionClassesForScopeInHints is cached per scope, so redundant lookups
  // within the same scope are avoided.
  context(traceScope: TraceScope)
  private fun findExternalBindingContainerContributions(
    scope: Scope,
    callingDeclaration: IrDeclaration,
  ): Set<IrClass> {
    // Track the lookup before checking the cache so all callers register their dependency
    trackScopeHintLookup(scope, callingDeclaration)
    return externalBindingContainerContributions
      .getOrPut(scope) {
        trace("Look up external contributions for $scope") {
          val contributingClasses =
            findVisibleContributionClassesForScopeInHints(scope, callingDeclaration)
          val finalSet = mutableScatterSetOf<IrClass>()
          // nativeContributions
          getScopedContributions(contributingClasses, scope, bindingContainersOnly = true).forEach {
            it.classOrNull
              ?.owner
              ?.takeIf { irClass -> with(metroContext) { irClass.isBindingContainer() } }
              ?.let(finalSet::add)
          }
          // extensionContributions
          irContributionExtensions.forEach { extension ->
            for (irClass in extension.contributeBindingContainers(scope, callingDeclaration)) {
              with(metroContext) { trackClassLookup(callingDeclaration, irClass) }
              finalSet.add(irClass)
            }
          }
          finalSet
        }
      }
      .asSet()
  }

  // Replacement processing is intentionally NOT done here. It's handled in
  // IrContributionMerger.computeContributions() after exclusions are applied, so that
  // excluded classes don't have their `replaces` effect applied.
  context(traceScope: TraceScope)
  private fun getScopedContributions(
    contributingClasses: Collection<IrClass>,
    scope: Scope,
    bindingContainersOnly: Boolean,
  ): Set<IrType> =
    trace("Get scoped contributions for $scope") {
      contributingClasses.flatMapToSet { irClass ->
        with(metroContext) {
          if (irClass.isBindingContainer()) {
            // Top-level @BindingContainer class
            if (bindingContainersOnly) {
              setOf(irClass.defaultType)
            } else {
              emptySet()
            }
          } else {
            // Walk nested @MetroContribution classes; route by their own @BindingContainer
            // annotation so pure-binding contributions land in the binding-container bucket
            // instead of being merged in as graph supertypes.
            irClass.nestedClasses.mapNotNullToSet { nestedClass ->
              val metroContribution =
                nestedClass.findAnnotations(Symbols.ClassIds.metroContribution).singleOrNull()
                  ?: return@mapNotNullToSet null
              val contributionScope =
                metroContribution.scopeOrNull()
                  ?: reportCompilerBug("No scope found for @MetroContribution annotation")
              if (contributionScope != scope) return@mapNotNullToSet null
              val isNestedContainer = nestedClass.isBindingContainer()
              if (bindingContainersOnly == isNestedContainer) {
                nestedClass.defaultType
              } else {
                null
              }
            }
          }
        }
      }
    }
}
